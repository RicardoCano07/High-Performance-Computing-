oldlist=['Adams','Baker','Clark','Davis','Evans','FranK','Yakub','Zafar']
newlist = map(str.upper, oldlist)
